// Defaults only. THERE IS NO API KEY IN THIS FILE.
//
// Disha starts in no-model mode: it matches your words against the page's own
// control names, works with no internet, and is capped below green by design.
// To get a green dot, open the popup, pick "Gemini API" and paste a free key
// from https://aistudio.google.com/apikey - it is stored in your browser, not here.
const GD_CONFIG = {
  provider: "offline",
  apiKey: "",
  baseUrl: "",
  models: ""
};
